/* global progressPlanner, prplInteractiveTaskFormListener */
/**
 * Update Term Description recommendation.
 *
 * Dependencies: progress-planner/recommendations/interactive-task, progress-planner/ajax-request, progress-planner/suggested-task
 */
( function () {
	/**
	 * Update Term Description class.
	 */
	class UpdateTermDescription {
		/**
		 * Constructor.
		 */
		constructor() {
			this.popoverId = 'prpl-popover-update-term-description';

			// Early return if the popover is not found.
			if ( ! document.getElementById( this.popoverId ) ) {
				return;
			}

			this.currentTermData = null;
			this.currentTaskElement = null;
			this.elements = this.getElements();
			this.init();
		}

		/**
		 * Get all DOM elements.
		 *
		 * @return {Object} Object containing all DOM elements.
		 */
		getElements() {
			const popover = document.getElementById( this.popoverId );

			return {
				popover,
				popoverTitle: popover.querySelector( '.prpl-popover-title' ),

				termNameElement: popover.querySelector(
					'#prpl-update-term-name'
				),
				taxonomyElement: popover.querySelector(
					'#prpl-update-term-taxonomy'
				),
				taxonomyNameElement: popover.querySelector(
					'#prpl-update-term-taxonomy-name'
				),
				termIdField: popover.querySelector( '#prpl-update-term-id' ),
				taxonomyField: popover.querySelector( '#prpl-update-taxonomy' ),
				descriptionField: popover.querySelector(
					'#prpl-term-description'
				),
			};
		}

		/**
		 * Initialize the component.
		 */
		init() {
			this.bindEvents();
		}

		/**
		 * Bind event listeners.
		 */
		bindEvents() {
			// Listen for the generic interactive task action event.
			document.addEventListener(
				'prpl-interactive-task-action-update-term-description',
				( event ) => {
					this.handleInteractiveTaskAction( event );

					// After the event is handled, initialize the form listener.
					this.initFormListener();
				}
			);
		}

		/**
		 * Handle interactive task action event.
		 *
		 * @param {CustomEvent} event The custom event with task context data.
		 */
		handleInteractiveTaskAction( event ) {
			this.currentTermData = {
				termId: this.decodeHtmlEntities( event.detail.target_term_id ),
				taxonomy: this.decodeHtmlEntities(
					event.detail.target_taxonomy
				),
				taxonomyName: this.decodeHtmlEntities(
					event.detail.target_taxonomy_name
				),
				termName: this.decodeHtmlEntities(
					event.detail.target_term_name
				),
			};

			// Store reference to the task element that triggered this.
			this.currentTaskElement = event.target.closest(
				'.prpl-suggested-task'
			);

			// Update the popover content with the term data.
			this.updatePopoverContent(
				this.currentTermData.termId,
				this.currentTermData.taxonomy,
				this.currentTermData.termName,
				this.currentTermData.taxonomyName,
				this.decodeHtmlEntities( event.detail.post_title )
			);
		}

		/**
		 * Update the popover content.
		 *
		 * @param {string} termId       The term ID.
		 * @param {string} taxonomy     The taxonomy.
		 * @param {string} termName     The term name.
		 * @param {string} taxonomyName The taxonomy name.
		 * @param {string} postTitle    The post title.
		 */
		updatePopoverContent(
			termId,
			taxonomy,
			termName,
			taxonomyName,
			postTitle
		) {
			if ( this.elements.popoverTitle ) {
				this.elements.popoverTitle.textContent = postTitle;
			}

			if ( this.elements.termNameElement ) {
				this.elements.termNameElement.textContent = termName;
			}

			if ( this.elements.taxonomyElement ) {
				this.elements.taxonomyElement.textContent = taxonomy;
			}

			if ( this.elements.taxonomyNameElement ) {
				this.elements.taxonomyNameElement.textContent = taxonomyName;
			}

			if ( this.elements.termIdField ) {
				this.elements.termIdField.value = termId;
			}

			if ( this.elements.taxonomyField ) {
				this.elements.taxonomyField.value = taxonomy;
			}

			// Clear the description field.
			if ( this.elements.descriptionField ) {
				this.elements.descriptionField.value = '';
			}
		}

		/**
		 * Initialize the form listener.
		 */
		initFormListener() {
			if ( ! this.currentTermData || ! this.currentTaskElement ) {
				return;
			}

			const formElement = this.elements.popover.querySelector( 'form' );

			if ( ! formElement ) {
				return;
			}

			// Submit button should be disabled if description is empty.
			const submitButton = document.getElementById(
				'prpl-update-term-description-button'
			);

			if ( submitButton ) {
				submitButton.disabled = true;
			}

			// Add event listener to description field.
			const descriptionField = formElement.querySelector(
				'#prpl-term-description'
			);
			if ( descriptionField ) {
				descriptionField.addEventListener( 'input', () => {
					submitButton.disabled = ! descriptionField.value.trim();
				} );
			}

			prplInteractiveTaskFormListener.customSubmit( {
				taskId: this.currentTaskElement.dataset.taskId,
				popoverId: this.popoverId,
				callback: () => {
					return new Promise( ( resolve, reject ) => {
						fetch( progressPlanner.ajaxUrl, {
							method: 'POST',
							headers: {
								'Content-Type':
									'application/x-www-form-urlencoded',
							},
							body: new URLSearchParams( {
								action: 'prpl_interactive_task_submit_update-term-description',
								nonce: progressPlanner.nonce,
								term_id: this.elements.termIdField.value,
								taxonomy: this.elements.taxonomyField.value,
								description:
									this.elements.descriptionField.value,
							} ),
						} )
							.then( () => {
								this.currentTaskElement = null;
								this.currentTermData = null;
							} )
							.then( ( response ) => {
								resolve( { response, success: true } );
							} )
							.catch( ( error ) => {
								reject( { success: false, error } );
							} );
					} );
				},
			} );
		}

		/**
		 * Decodes HTML entities in a string (like &quot;, &amp;, etc.)
		 * @param {string} str The string to decode.
		 * @return {string} The decoded string.
		 */
		decodeHtmlEntities( str ) {
			if ( typeof str !== 'string' ) {
				return str;
			}

			return str
				.replace( /&quot;/g, '"' )
				.replace( /&#039;/g, "'" )
				.replace( /&lt;/g, '<' )
				.replace( /&gt;/g, '>' )
				.replace( /&amp;/g, '&' );
		}
	}

	// Initialize the component.
	new UpdateTermDescription();
} )();
