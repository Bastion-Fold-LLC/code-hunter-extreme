/* global HTMLElement, prplSuggestedTask, prplL10n, prplUpdateRaviGauge, prplTerms */
/*
 * Suggested Task scripts & helpers.
 *
 * Dependencies: wp-api, progress-planner/l10n, progress-planner/suggested-task-terms, progress-planner/web-components/prpl-gauge, progress-planner/widgets/suggested-tasks
 */
/* eslint-disable camelcase, jsdoc/require-param-type, jsdoc/require-param, jsdoc/check-param-names */

prplSuggestedTask = {
	...prplSuggestedTask,
	injectedItemIds: [],
	l10n: {
		info: prplL10n( 'info' ),
		moveUp: prplL10n( 'moveUp' ),
		moveDown: prplL10n( 'moveDown' ),
		snooze: prplL10n( 'snooze' ),
		disabledRRCheckboxTooltip: prplL10n( 'disabledRRCheckboxTooltip' ),
		markAsComplete: prplL10n( 'markAsComplete' ),
		taskDelete: prplL10n( 'taskDelete' ),
		delete: prplL10n( 'delete' ),
		whyIsThisImportant: prplL10n( 'whyIsThisImportant' ),
	},

	/**
	 * Fetch items for arguments.
	 *
	 * @param {Object} args The arguments to pass to the injectItems method.
	 * @return {Promise} A promise that resolves with the collection of posts.
	 */
	fetchItems: ( args ) => {
		console.info(
			`Fetching recommendations with args: ${ JSON.stringify( args ) }...`
		);

		const fetchData = {
			status: args.status,
			per_page: args.per_page || 100,
			_embed: true,
			exclude: prplSuggestedTask.injectedItemIds,
			filter: {
				orderby: 'menu_order',
				order: 'ASC',
			},
		};

		// Pass through provider and exclude_provider if provided.
		if ( args.provider ) {
			fetchData.provider = args.provider;
		}
		if ( args.exclude_provider ) {
			fetchData.exclude_provider = args.exclude_provider;
		}

		return prplSuggestedTask
			.getPostsCollectionPromise( { data: fetchData } )
			.then( ( response ) => response.data );
	},

	/**
	 * Inject items.
	 *
	 * @param {Object[]} items The items to inject.
	 */
	injectItems: ( items ) => {
		if ( items.length ) {
			// Inject the items into the DOM.
			items.forEach( ( item ) => {
				document.dispatchEvent(
					new CustomEvent( 'prpl/suggestedTask/injectItem', {
						detail: {
							item,
							listId: 'prpl-suggested-tasks-list',
							insertPosition: 'beforeend',
						},
					} )
				);
				prplSuggestedTask.injectedItemIds.push( item.id );
			} );
		}

		// Trigger the grid resize event.
		window.dispatchEvent( new CustomEvent( 'prpl/grid/resize' ) );
	},

	/**
	 * Get a collection of posts.
	 *
	 * @param {Object} fetchArgs The arguments to pass to the fetch method.
	 * @return {Promise} A promise that resolves with the collection of posts.
	 */
	getPostsCollectionPromise: ( fetchArgs ) => {
		const collectionsPromise = new Promise( ( resolve ) => {
			const postsCollection =
				new wp.api.collections.Prpl_recommendations();
			postsCollection
				.fetch( fetchArgs )
				.done( ( data ) => resolve( { data, postsCollection } ) );
		} );

		return collectionsPromise;
	},

	/**
	 * Render a new item.
	 *
	 * @param {Object} post The post object.
	 */
	getNewItemTemplatePromise: ( { post = {}, listId = '' } ) =>
		new Promise( ( resolve ) => {
			const { prpl_recommendations_provider } = post;
			const terms = { prpl_recommendations_provider };

			Object.values( prplTerms.get( 'provider' ) ).forEach( ( term ) => {
				if ( term.id === terms[ prplTerms.provider ][ 0 ] ) {
					terms[ prplTerms.provider ] = term;
				}
			} );

			const template = wp.template( 'prpl-suggested-task' );
			const data = {
				post,
				terms,
				listId,
				assets: prplSuggestedTask.assets,
				action: 'pending' === post.status ? 'celebrate' : '',
				l10n: prplSuggestedTask.l10n,
			};

			resolve( template( data ) );
		} ),

	/**
	 * Run a task action.
	 *
	 * @param {number} postId     The post ID.
	 * @param {string} actionType The action type.
	 * @return {Promise} A promise that resolves with the response from the server.
	 */
	runTaskAction: ( postId, actionType ) =>
		wp.ajax.post( 'progress_planner_suggested_task_action', {
			post_id: postId,
			nonce: prplSuggestedTask.nonce,
			action_type: actionType,
		} ),

	/**
	 * Trash (delete) a task.
	 * Only user tasks can be trashed.
	 *
	 * @param {number} postId The post ID.
	 */
	trash: ( postId ) => {
		const post = new wp.api.models.Prpl_recommendations( {
			id: postId,
		} );
		post.fetch().then( () => {
			// Handle the case when plain URL structure is used, it used to result in invalid URL (404): http://localhost:8080/index.php?rest_route=/wp/v2/prpl_recommendations/35?force=true
			const url = post.url().includes( 'rest_route=' )
				? post.url() + '&force=true'
				: post.url() + '?force=true';

			post.destroy( { url } ).then( () => {
				// Remove the task from the todo list.
				prplSuggestedTask.removeTaskElement( postId );

				// Fetch and inject a replacement task
				prplSuggestedTask.fetchAndInjectReplacementTask();

				setTimeout(
					() =>
						window.dispatchEvent(
							new CustomEvent( 'prpl/grid/resize' )
						),
					500
				);

				prplSuggestedTask.runTaskAction( postId, 'delete' );
			} );
		} );
	},

	/**
	 * Maybe complete a task.
	 *
	 * @param {number} postId The post ID.
	 */
	maybeComplete: ( postId ) => {
		// Return the promise chain so callers can wait for completion
		return new Promise( ( resolve, reject ) => {
			// Get the task.
			const post = new wp.api.models.Prpl_recommendations( {
				id: postId,
			} );
			post.fetch()
				.then( ( postData ) => {
					const taskProviderId = prplTerms.getTerm(
						postData?.[ prplTerms.provider ],
						prplTerms.provider
					).slug;

					const el = prplSuggestedTask.getTaskElement( postId );

					// Dismissable tasks don't have pending status, it's either publish or trash.
					const newStatus =
						'publish' === postData.status ? 'trash' : 'publish';

					// Disable the checkbox for RR tasks, to prevent multiple clicks.
					el.querySelector(
						'.prpl-suggested-task-checkbox'
					)?.setAttribute( 'disabled', 'disabled' );

					post.set( 'status', newStatus )
						.save()
						.then( () => {
							prplSuggestedTask.runTaskAction(
								postId,
								'trash' === newStatus ? 'complete' : 'pending'
							);
							const eventPoints = parseInt(
								postData?.prpl_points
							);

							// Task is trashed, check if we need to celebrate.
							if ( 'trash' === newStatus ) {
								el.setAttribute(
									'data-task-action',
									'celebrate'
								);
								if ( 'user' === taskProviderId ) {
									// Set class to trigger strike through animation.
									el.classList.add(
										'prpl-suggested-task-celebrated'
									);

									setTimeout( () => {
										// Move task from published to trash.
										document
											.getElementById(
												'todo-list-completed'
											)
											.insertAdjacentElement(
												'beforeend',
												el
											);

										// Remove the class to trigger the strike through animation.
										el.classList.remove(
											'prpl-suggested-task-celebrated'
										);

										window.dispatchEvent(
											new CustomEvent(
												'prpl/grid/resize'
											)
										);

										// Remove the disabled attribute for user tasks, so they can be clicked again.
										el.querySelector(
											'.prpl-suggested-task-checkbox'
										)?.removeAttribute( 'disabled' );

										// Resolve the promise after the timeout completes
										resolve( {
											postId,
											newStatus,
											eventPoints,
										} );
									}, 2000 );
								} else {
									// Check the chekcbox, since completing task can be triggered in different ways ("Mark as done" button), without triggering the onchange event.
									const checkbox = el.querySelector(
										'.prpl-suggested-task-checkbox'
									);
									if ( checkbox ) {
										checkbox.checked = true;
									}

									/**
									 * Strike completed tasks and remove them from the DOM.
									 */
									document.dispatchEvent(
										new CustomEvent(
											'prpl/removeCelebratedTasks'
										)
									);

									// Fetch and inject a replacement task for non-user tasks
									prplSuggestedTask.fetchAndInjectReplacementTask();

									// Resolve immediately for non-user tasks
									resolve( {
										postId,
										newStatus,
										eventPoints,
									} );
								}

								// We trigger celebration only if the task has points.
								if ( 0 < eventPoints ) {
									prplUpdateRaviGauge( eventPoints );

									// Trigger the celebration event (confetti).
									document.dispatchEvent(
										new CustomEvent(
											'prpl/celebrateTasks',
											{
												detail: { element: el },
											}
										)
									);
								}
							} else if (
								'publish' === newStatus &&
								'user' === taskProviderId
							) {
								// This is only possible for user tasks.
								// Set the task action to publish.
								el.setAttribute(
									'data-task-action',
									'publish'
								);

								// Update the Ravi gauge.
								prplUpdateRaviGauge( 0 - eventPoints );

								// Move task from trash to published, tasks with points go to the beginning of the list.
								document
									.getElementById( 'todo-list' )
									.insertAdjacentElement(
										0 < eventPoints
											? 'afterbegin'
											: 'beforeend',
										el
									);

								window.dispatchEvent(
									new CustomEvent( 'prpl/grid/resize' )
								);

								// Remove the disabled attribute for user tasks, so they can be clicked again.
								el.querySelector(
									'.prpl-suggested-task-checkbox'
								)?.removeAttribute( 'disabled' );

								// Resolve immediately for publish actions
								resolve( { postId, newStatus, eventPoints } );
							}
						} )
						.catch( reject );
				} )
				.catch( reject );
		} );
	},

	/**
	 * Snooze a task.
	 *
	 * @param {number} postId         The post ID.
	 * @param {string} snoozeDuration The snooze duration.
	 */
	snooze: ( postId, snoozeDuration ) => {
		const snoozeDurationMap = {
			'1-week': 7,
			'2-weeks': 14,
			'1-month': 30,
			'3-months': 90,
			'6-months': 180,
			'1-year': 365,
			forever: 3650,
		};

		const snoozeDurationDays = snoozeDurationMap[ snoozeDuration ];
		const date = new Date(
			Date.now() + snoozeDurationDays * 24 * 60 * 60 * 1000
		)
			.toISOString()
			.split( '.' )[ 0 ];
		const postModelToSave = new wp.api.models.Prpl_recommendations( {
			id: postId,
			status: 'future',
			date,
			date_gmt: date,
		} );
		postModelToSave.save().then( () => {
			prplSuggestedTask.removeTaskElement( postId );

			// Fetch and inject a replacement task
			prplSuggestedTask.fetchAndInjectReplacementTask();
		} );
	},

	/**
	 * Run a tooltip action.
	 *
	 * @param {HTMLElement} button The button that was clicked.
	 */
	runButtonAction: ( button ) => {
		let action = button.getAttribute( 'data-action' );
		const target = button.getAttribute( 'data-target' );
		const item = button.closest( 'li.prpl-suggested-task' );
		const tooltipActions = item.querySelector( '.tooltip-actions' );
		const elClass = '.prpl-suggested-task-' + target;

		// If the tooltip was already open, close it.
		if (
			!! tooltipActions.querySelector(
				`${ elClass }[data-tooltip-visible]`
			)
		) {
			action = 'close-' + target;
		} else {
			const closestTaskListVisible = item
				.closest( '.prpl-suggested-tasks-list' )
				.querySelector( `[data-tooltip-visible]` );
			// Close the any opened radio group.
			closestTaskListVisible?.classList.remove(
				'prpl-toggle-radio-group-open'
			);
			// Remove any existing tooltip visible attribute, in the entire list.
			closestTaskListVisible?.removeAttribute( 'data-tooltip-visible' );
		}

		switch ( action ) {
			case 'move-up':
			case 'move-down':
				if ( 'move-up' === action && item.previousElementSibling ) {
					item.parentNode.insertBefore(
						item,
						item.previousElementSibling
					);
				} else if (
					'move-down' === action &&
					item.nextElementSibling
				) {
					item.parentNode.insertBefore(
						item.nextElementSibling,
						item
					);
				}
				// Trigger a custom event.
				document.dispatchEvent(
					new CustomEvent( 'prpl/suggestedTask/move', {
						detail: { node: item },
					} )
				);
				break;
		}
	},

	/**
	 * Update the task title.
	 *
	 * @param {HTMLElement} el The element that was edited.
	 */
	updateTaskTitle: ( el ) => {
		// Add debounce to the input event.
		clearTimeout( this.debounceTimeout );
		this.debounceTimeout = setTimeout( () => {
			// Update an existing post.
			const title = el.textContent.replace( /\n/g, '' );
			const postModel = new wp.api.models.Prpl_recommendations( {
				id: parseInt( el.getAttribute( 'data-post-id' ) ),
				title,
			} );
			postModel.save().then( () =>
				// Update the task title.
				document.dispatchEvent(
					new CustomEvent( 'prpl/suggestedTask/update', {
						detail: {
							node: el.closest( 'li.prpl-suggested-task' ),
						},
					} )
				)
			);
			// Use textContent (not innerHTML) so a title typed into the
			// contenteditable field cannot inject markup.
			el
				.closest( 'li.prpl-suggested-task' )
				.querySelector(
					'label:has(.prpl-suggested-task-checkbox) .screen-reader-text'
				).textContent = `${ title }: ${ prplL10n( 'markAsComplete' ) }`;
		}, 300 );
	},

	/**
	 * Prevent Enter key in contenteditable elements.
	 *
	 * @param {Event} event The keydown event.
	 */
	preventEnterKey: ( event ) => {
		if ( event.key === 'Enter' ) {
			event.preventDefault();
			event.stopPropagation();
			event.target.blur();
			return false;
		}
	},

	/**
	 * Get the task element.
	 *
	 * @param {number} postId The post ID.
	 * @return {HTMLElement} The task element.
	 */
	getTaskElement: ( postId ) =>
		document.querySelector(
			`.prpl-suggested-task[data-post-id="${ postId }"]`
		),

	/**
	 * Remove the task element.
	 *
	 * @param {number} postId The post ID.
	 */
	removeTaskElement: ( postId ) =>
		prplSuggestedTask.getTaskElement( postId )?.remove(),

	/**
	 * Fetch and inject a replacement task after one is removed.
	 *
	 * Replacement tasks are always fetched for the suggested-tasks-list,
	 * which excludes user tasks (user tasks have their own todo list).
	 */
	fetchAndInjectReplacementTask: () => {
		// Collect all currently visible task IDs from the DOM
		const visibleTaskIds = Array.from(
			document.querySelectorAll( '.prpl-suggested-task[data-post-id]' )
		).map( ( el ) => parseInt( el.getAttribute( 'data-post-id' ) ) );

		// Combine with injectedItemIds to ensure we have a complete exclusion list
		const allTaskIds = [
			...new Set( [
				...prplSuggestedTask.injectedItemIds,
				...visibleTaskIds,
			] ),
		];

		// Update injectedItemIds to include any tasks that might have been missed
		prplSuggestedTask.injectedItemIds = allTaskIds;

		const fetchArgs = {
			status: 'publish',
			per_page: 1,
			exclude_provider: 'user', // Always exclude user tasks from suggested-tasks-list
		};

		prplSuggestedTask.fetchItems( fetchArgs ).then( ( items ) => {
			if ( items && items.length > 0 ) {
				prplSuggestedTask.injectItems( items );
			}
		} );
	},
};

/**
 * Inject an item.
 */
document.addEventListener( 'prpl/suggestedTask/injectItem', ( event ) => {
	prplSuggestedTask
		.getNewItemTemplatePromise( {
			post: event.detail.item,
			listId: event.detail.listId,
		} )
		.then( ( itemHTML ) => {
			/**
			 * @todo Implement the parent task functionality.
			 * Use this code: `const parent = event.detail.item.parent && '' !== event.detail.item.parent ? event.detail.item.parent : null;
			 */
			const parent = false;

			if ( ! parent ) {
				// Inject the item into the list.
				document
					.getElementById( event.detail.listId )
					.insertAdjacentHTML(
						event.detail.insertPosition,
						itemHTML
					);

				// Trigger the grid resize event.
				window.dispatchEvent( new CustomEvent( 'prpl/grid/resize' ) );

				return;
			}

			// If we could not find the parent item, try again after 500ms.
			window.prplRenderAttempts = window.prplRenderAttempts || 0;
			if ( window.prplRenderAttempts > 20 ) {
				return;
			}
			const parentItem = document.querySelector(
				`.prpl-suggested-task[data-task-id="${ parent }"]`
			);
			if ( ! parentItem ) {
				setTimeout( () => {
					document.dispatchEvent(
						new CustomEvent( 'prpl/suggestedTask/injectItem', {
							detail: {
								item: event.detail.item,
								listId: event.detail.listId,
								insertPosition: event.detail.insertPosition,
							},
						} )
					);
					window.prplRenderAttempts++;
				}, 100 );
				return;
			}

			// If the child list does not exist, create it.
			if (
				! parentItem.querySelector( '.prpl-suggested-task-children' )
			) {
				const childListElement = document.createElement( 'ul' );
				childListElement.classList.add(
					'prpl-suggested-task-children'
				);
				parentItem.appendChild( childListElement );
			}

			// Inject the item into the child list.
			parentItem
				.querySelector( '.prpl-suggested-task-children' )
				.insertAdjacentHTML( 'beforeend', itemHTML );
		} );
} );

// When the 'prpl/suggestedTask/move' event is triggered,
// update the menu_order of the todo items.
document.addEventListener( 'prpl/suggestedTask/move', ( event ) => {
	const listUl = event.detail.node.closest( 'ul' );
	const todoItemsIDs = [];
	// Get all the todo items.
	const todoItems = listUl.querySelectorAll( '.prpl-suggested-task' );
	let menuOrder = 0;
	todoItems.forEach( ( todoItem ) => {
		const itemID = parseInt( todoItem.getAttribute( 'data-post-id' ) );
		todoItemsIDs.push( itemID );
		todoItem.setAttribute( 'data-task-order', menuOrder );

		listUl
			.querySelector( `.prpl-suggested-task[data-post-id="${ itemID }"]` )
			.setAttribute( 'data-task-order', menuOrder );

		// Update an existing post.
		const post = new wp.api.models.Prpl_recommendations( {
			id: itemID,
			menu_order: menuOrder,
		} );
		post.save();
		menuOrder++;
	} );
} );

/* eslint-enable camelcase, jsdoc/require-param-type, jsdoc/require-param, jsdoc/check-param-names */
