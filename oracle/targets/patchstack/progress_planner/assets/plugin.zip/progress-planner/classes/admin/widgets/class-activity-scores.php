<?php
/**
 * A widget class.
 *
 * @package Progress_Planner
 */

namespace Progress_Planner\Admin\Widgets;

use Progress_Planner\Goals\Goal_Recurring;
use Progress_Planner\Goals\Goal;

/**
 * A widget class.
 */
final class Activity_Scores extends Widget {

	/**
	 * The widget ID.
	 *
	 * @var string
	 */
	protected $id = 'activity-scores';

	/**
	 * The cache key.
	 *
	 * @var string
	 */
	protected $cache_key = 'activities_weekly_post_record';

	/**
	 * The color callback.
	 *
	 * @param int       $number The number to calculate the color for.
	 * @param \DateTime $date   The date.
	 *
	 * @return string The color.
	 */
	public function get_color( $number, $date ) {
		// If monthly and the latest month, return gray (in progress).
		if (
			'monthly' === $this->get_frequency() &&
			\gmdate( 'Y-m-01' ) === $date->format( 'Y-m-01' )
		) {
			return 'var(--prpl-color-border)';
		}

		// If weekly and the current week, return gray (in progress).
		if (
			'weekly' === $this->get_frequency() &&
			\gmdate( 'Y-W' ) === $date->format( 'Y-W' )
		) {
			return 'var(--prpl-color-border)';
		}

		if ( $number > 90 ) {
			return 'var(--prpl-graph-color-3)';
		}
		if ( $number > 30 ) {
			return 'var(--prpl-color-monthly)';
		}
		return 'var(--prpl-graph-color-1)';
	}

	/**
	 * Get the score.
	 *
	 * @return int The score.
	 */
	public function get_score() {
		$activities = \progress_planner()->get_activities__query()->query_activities(
			// Use 31 days to take into account the activities score decay from previous activities.
			[ 'start_date' => new \DateTime( '-31 days' ) ]
		);

		$score        = 0;
		$current_date = new \DateTime();
		foreach ( $activities as $activity ) {
			$score += $activity->get_points( $current_date );
		}
		$score = \min( 100, \max( 0, $score ) );

		// Get the number of pending updates.
		$pending_updates = \wp_get_update_data()['counts']['total'];

		// Reduce points for pending updates.
		$score -= \min( \min( $score / 2, 25 ), $pending_updates * 5 );
		return (int) \floor( $score );
	}

	/**
	 * Get the checklist results.
	 *
	 * @return array<string, bool> The checklist results.
	 */
	public function get_checklist_results() {
		$items   = $this->get_checklist();
		$results = [];
		foreach ( $items as $item ) {
			$label             = (string) $item['label']; // @phpstan-ignore offsetAccess.invalidOffset
			$results[ $label ] = $item['callback'](); // @phpstan-ignore offsetAccess.invalidOffset
		}
		return $results;
	}

	/**
	 * Get the checklist items.
	 *
	 * @return array The checklist items.
	 */
	public function get_checklist() {
		return [
			[
				'label'    => \esc_html__( 'published content', 'progress-planner' ),
				'callback' => fn() => \count(
					\progress_planner()->get_activities__query()->query_activities(
						[
							'start_date' => new \DateTime( '-7 days' ),
							'category'   => 'content',
							'type'       => 'publish',
						]
					)
				) > 0,
			],
			[
				'label'    => \esc_html__( 'updated content', 'progress-planner' ),
				'callback' => fn() => \count(
					\progress_planner()->get_activities__query()->query_activities(
						[
							'start_date' => new \DateTime( '-7 days' ),
							'category'   => 'content',
							'type'       => 'update',
						]
					)
				) > 0,
			],
			[
				'label'    => 0 === \wp_get_update_data()['counts']['total']
					? \esc_html__( 'performed all updates', 'progress-planner' )
					: '<a href="' . \esc_url( \admin_url( 'update-core.php' ) ) . '">' . \esc_html__( 'Perform all updates', 'progress-planner' ) . '</a>',
				'callback' => fn() => ! \wp_get_update_data()['counts']['total'],
			],
		];
	}

	/**
	 * Get the gauge color.
	 *
	 * @param int $score The score.
	 *
	 * @return string The color.
	 */
	public function get_gauge_color( $score ) {
		if ( $score >= 75 ) {
			return 'var(--prpl-graph-color-3)';
		}
		if ( $score >= 50 ) {
			return 'var(--prpl-color-monthly)';
		}
		return 'var(--prpl-graph-color-1)';
	}

	/**
	 * Get the personal record goal.
	 *
	 * @return array
	 */
	public function personal_record_callback() {
		$goal = Goal_Recurring::get_instance(
			'weekly_post_record',
			[
				'class_name'  => Goal::class,
				'id'          => 'weekly_post',
				'title'       => \esc_html__( 'Write a weekly blog post', 'progress-planner' ),
				'description' => \esc_html__( 'Streak: The number of weeks this goal has been accomplished consistently.', 'progress-planner' ),
				'status'      => 'active',
				'priority'    => 'low',
				'evaluate'    => function ( $goal_object ) {
					// Get the cached activities.
					$cached_activities = \progress_planner()->get_settings()->get( $this->cache_key, [] );

					// Get the weekly cache key.
					$weekly_cache_key = $goal_object->get_details()['start_date']->format( 'Y-m-d' ) . '_' . $goal_object->get_details()['end_date']->format( 'Y-m-d' );

					// If the cache is set, return the cached value.
					if ( isset( $cached_activities[ $weekly_cache_key ] ) ) {
						return (bool) $cached_activities[ $weekly_cache_key ];
					}

					// Get the activities.
					$activities = \progress_planner()->get_activities__query()->query_activities(
						[
							'category'   => 'content',
							'type'       => 'publish',
							'start_date' => $goal_object->get_details()['start_date'],
							'end_date'   => $goal_object->get_details()['end_date'],
						]
					);

					// Cache the activities.
					$cached_activities[ $weekly_cache_key ] = (bool) \count( $activities );
					\progress_planner()->get_settings()->set( $this->cache_key, $cached_activities );

					// Return the cached value.
					return $cached_activities[ $weekly_cache_key ];
				},
			],
			[
				'frequency'     => 'weekly',
				'start_date'    => \progress_planner()->get_activation_date(),
				'end_date'      => new \DateTime(), // Today.
				'allowed_break' => 0, // Do not allow breaks in the streak.
			]
		);

		return $goal->get_streak();
	}

	/**
	 * Get the cache key.
	 *
	 * @return string The cache key.
	 */
	public function get_cache_key() {
		return $this->cache_key;
	}
}
