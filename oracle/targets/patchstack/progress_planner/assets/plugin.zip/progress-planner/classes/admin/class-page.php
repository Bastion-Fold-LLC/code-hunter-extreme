<?php
/**
 * Create the admin page.
 *
 * @package Progress_Planner
 */

namespace Progress_Planner\Admin;

/**
 * Admin page class.
 */
class Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register the hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		\add_action( 'admin_menu', [ $this, 'add_page' ] );
		\add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		\add_action( 'in_admin_header', [ $this, 'remove_admin_notices' ], PHP_INT_MAX );

		// Clear the cache for the activity scores widget.
		\add_action( 'progress_planner_activity_saved', [ $this, 'clear_activity_scores_cache' ] );
		\add_action( 'progress_planner_activity_deleted', [ $this, 'clear_activity_scores_cache' ] );

		// Add a custom admin footer.
		\add_action( 'admin_footer', [ $this, 'admin_footer' ] );
	}

	/**
	 * Get the widgets objects
	 *
	 * @return array<\Progress_Planner\Admin\Widgets\Widget>
	 */
	public function get_widgets() {
		$widgets = [
			\progress_planner()->get_admin__widgets__suggested_tasks(),
			\progress_planner()->get_admin__widgets__todo(),
			\progress_planner()->get_admin__widgets__monthly_badges(),
			\progress_planner()->get_admin__widgets__badge_streak_content(),
			\progress_planner()->get_admin__widgets__badge_streak_maintenance(),
			\progress_planner()->get_admin__widgets__challenge(),
			\progress_planner()->get_admin__widgets__activity_scores(),
			\progress_planner()->get_admin__widgets__content_activity(),
			\progress_planner()->get_admin__widgets__whats_new(),
		];

		/**
		 * Filter the widgets.
		 *
		 * @param array<\Progress_Planner\Admin\Widgets\Widget> $widgets The widgets.
		 *
		 * @return array<\Progress_Planner\Admin\Widgets\Widget>
		 */
		return \apply_filters( 'progress_planner_admin_widgets', $widgets ); // @phpstan-ignore-line parameter.phpDocType
	}

	/**
	 * Get a widget object.
	 *
	 * @param string $id The widget ID.
	 *
	 * @return \Progress_Planner\Admin\Widgets\Widget|void
	 */
	public function get_widget( $id ) {
		$widgets = $this->get_widgets();
		foreach ( $widgets as $widget ) {
			if ( $widget->get_id() === $id ) {
				return $widget;
			}
		}
	}

	/**
	 * Add the admin page.
	 *
	 * @return void
	 */
	public function add_page() {
		global $admin_page_hooks;

		$page_identifier = 'progress-planner';

		\add_menu_page(
			\progress_planner()->get_ui__branding()->get_admin_submenu_name(),
			\progress_planner()->get_ui__branding()->get_admin_menu_name() . $this->get_notification_counter(),
			'manage_options',
			$page_identifier,
			'__return_empty_string',
			\progress_planner()->get_ui__branding()->get_admin_menu_icon(),
			\progress_planner()->get_ui__branding()->get_admin_submenu_position()
		);

		\add_submenu_page(
			$page_identifier,
			\progress_planner()->get_ui__branding()->get_admin_submenu_name(),
			\progress_planner()->get_ui__branding()->get_admin_submenu_name() . $this->get_notification_counter(),
			'manage_options',
			$page_identifier,
			[ $this, 'render_page' ],
		);

		// Wipe notification bits from hooks.
		// phpcs:ignore WordPress.WP.GlobalVariablesOverride -- This is a deliberate action.
		$admin_page_hooks[ $page_identifier ] = $page_identifier;
	}

	/**
	 * Returns the notification count in HTML format.
	 *
	 * @return string The notification count in HTML format.
	 */
	protected function get_notification_counter() {
		$notification_count = \wp_count_posts( 'prpl_recommendations' )->pending;

		if ( 0 === $notification_count ) {
			return '';
		}

		/* translators: Hidden accessibility text; %s: number of notifications. */
		$notifications = \sprintf( \_n( '%s pending celebration', '%s pending celebrations', $notification_count, 'progress-planner' ), \number_format_i18n( $notification_count ) );

		return \sprintf( '<span class="update-plugins count-%1$d" style="background-color:var(--prpl-background-banner);color:#38296d;"><span class="plugin-count" aria-hidden="true">%1$d</span><span class="screen-reader-text">%2$s</span></span>', $notification_count, $notifications );
	}

	/**
	 * Render the admin page.
	 *
	 * @return void
	 */
	public function render_page() {
		\progress_planner()->the_view( 'admin-page.php' );
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @param string $hook The current admin page.
	 *
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		$this->maybe_enqueue_focus_el_script( $hook );
		if ( 'toplevel_page_progress-planner' !== $hook ) {
			return;
		}

		$this->enqueue_scripts();
		$this->enqueue_styles();
	}

	/**
	 * Enqueue scripts.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		$current_screen = \get_current_screen();
		if ( ! $current_screen ) {
			return;
		}

		if ( 'toplevel_page_progress-planner' === $current_screen->id ) {
			$default_localization_data = [
				'name' => 'progressPlanner',
				'data' => [
					'onboardNonceURL' => \progress_planner()->get_utils__onboard()->get_remote_url( 'get-nonce' ),
					'onboardAPIUrl'   => \progress_planner()->get_utils__onboard()->get_remote_url( 'onboard' ),
					'ajaxUrl'         => \admin_url( 'admin-ajax.php' ),
					'nonce'           => \wp_create_nonce( 'progress_planner' ),
				],
			];

			if ( true === \progress_planner()->is_privacy_policy_accepted() ) {
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-gauge' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-badge-progress-bar' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-chart-bar' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-chart-line' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-big-counter' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'web-components/prpl-tooltip' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'header-filters', $default_localization_data );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'settings', $default_localization_data );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'grid-masonry' );
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'upgrade-tasks' );
			} else {
				\progress_planner()->get_admin__enqueue()->enqueue_script( 'onboard', $default_localization_data );
			}

			\progress_planner()->get_admin__enqueue()->enqueue_script( 'external-link-accessibility-helper' );
		}
	}

	/**
	 * Enqueue the focus element script.
	 *
	 * @param string $hook The current admin page.
	 *
	 * @return void
	 */
	public function maybe_enqueue_focus_el_script( $hook ) {
		// Get all registered task providers from the task manager.
		$tasks_providers  = \progress_planner()->get_suggested_tasks()->get_tasks_manager()->get_task_providers();
		$tasks_details    = [];
		$total_points     = 0;
		$completed_points = 0;

		// Filter providers to only those relevant to the current admin page.
		foreach ( $tasks_providers as $provider ) {
			$link_setting = $provider->get_link_setting();

			// Skip tasks that aren't configured for this admin page.
			if ( ! isset( $link_setting['hook'] ) ||
				$hook !== $link_setting['hook']
			) {
				continue;
			}

			// Build task details for JavaScript.
			$details = [
				'link_setting' => $link_setting, // Contains selector, hook, and highlight config.
				'task_id'      => $provider->get_task_id(),
				'points'       => $provider->get_points(),
				'is_complete'  => $provider->is_task_completed(),
			];

			$tasks_details[] = $details;
			$total_points   += $details['points'];
			if ( $details['is_complete'] ) {
				$completed_points += $details['points'];
			}
		}

		// No tasks for this page - don't enqueue the script.
		if ( empty( $tasks_details ) ) {
			return;
		}

		// Enqueue the focus element script with task data.
		\progress_planner()->get_admin__enqueue()->enqueue_script(
			'focus-element',
			[
				'name' => 'progressPlannerFocusElement',
				'data' => [
					'tasks'           => $tasks_details,
					'totalPoints'     => $total_points,
					'completedPoints' => $completed_points,
					'iconUrl'         => \progress_planner()->get_ui__branding()->get_admin_menu_icon(),
					'l10n'            => [
						/* translators: %d: The number of points. */
						'fixThisIssue' => \esc_html__( 'Fix this issue to get %d point(s) in Progress Planner', 'progress-planner' ),
					],
				],
			]
		);
		\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/focus-element' );
	}

	/**
	 * Enqueue styles.
	 *
	 * @return void
	 */
	public function enqueue_styles() {
		$current_screen = \get_current_screen();
		if ( ! $current_screen ) {
			return;
		}

		\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/variables-color' );
		\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/admin' );
		\progress_planner()->get_ui__branding()->enqueue_inline_css( 'progress-planner/admin' );
		\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/web-components/prpl-tooltip' );
		\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/web-components/prpl-install-plugin' );

		if ( 'toplevel_page_progress-planner' === $current_screen->id ) {
			// Enqueue ugprading (onboarding) tasks styles, these are needed both when privacy policy is accepted and when it is not.
			\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/upgrade-tasks' );
		}

		$prpl_privacy_policy_accepted = \progress_planner()->is_privacy_policy_accepted();
		if ( ! $prpl_privacy_policy_accepted ) {
			// Enqueue welcome styles.
			\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/welcome' );

			// Enqueue onboarding styles.
			\progress_planner()->get_admin__enqueue()->enqueue_style( 'progress-planner/onboard' );
		}
	}

	/**
	 * Remove all admin notices when the user is on the Progress Planner page.
	 *
	 * @return void
	 */
	public function remove_admin_notices() {
		$current_screen = \get_current_screen();
		if ( ! $current_screen ) {
			return;
		}
		if ( ! \in_array(
			$current_screen->id,
			[
				'toplevel_page_progress-planner',
			],
			true
		) ) {
			return;
		}

		\remove_all_actions( 'admin_notices' );
		\remove_all_actions( 'all_admin_notices' );
	}

	/**
	 * Clear the cache.
	 *
	 * @param \Progress_Planner\Activities\Activity $activity The activity.
	 *
	 * @return void
	 */
	public function clear_activity_scores_cache( $activity ) {
		if ( 'content' !== $activity->category ) {
			return;
		}

		// Clear the cache for the activity scores widget.
		\progress_planner()->get_settings()->set( \progress_planner()->get_admin__widgets__activity_scores()->get_cache_key(), [] );
	}

	/**
	 * Add a custom admin footer.
	 *
	 * @return void
	 */
	public function admin_footer() {
		?>
		<style>
			#toplevel_page_progress-planner {
				position: relative;
				.update-plugins {
					position: absolute;
					left: 18px;
					bottom: 0px;
					min-width: 15px;
					height: 15px;
					line-height: 1.5;
				}

				.wp-submenu {
					.update-plugins {
						display: none;
					}
				}
			}
		</style>
		<?php
	}
}
