<?php
/**
 * Abstract class for a task provider.
 *
 * @package Progress_Planner
 */

namespace Progress_Planner\Suggested_Tasks\Providers;

use Progress_Planner\Suggested_Tasks\Tasks_Interface;

/**
 * Add tasks for content updates.
 */
abstract class Tasks implements Tasks_Interface {

	/**
	 * The ID of the task provider.
	 *
	 * @var string
	 */
	protected const PROVIDER_ID = '';

	/**
	 * The capability required to perform the task.
	 *
	 * @var string
	 */
	protected const CAPABILITY = 'manage_options';

	/**
	 * Whether the task is an onboarding task.
	 *
	 * @var bool
	 */
	protected const IS_ONBOARDING_TASK = false;

	/**
	 * The data collector class name.
	 *
	 * @var string
	 */
	protected const DATA_COLLECTOR_CLASS = \Progress_Planner\Suggested_Tasks\Data_Collector\Base_Data_Collector::class;

	/**
	 * Dependencies on other tasks.
	 *
	 * The key is the task-ID of the other task,
	 * If the value is true, the task is pending, if false, the task is completed/dismissed/snoozed.
	 *
	 * @var array<string, bool>
	 */
	protected const DEPENDENCIES = [];

	/**
	 * The external link URL.
	 *
	 * @var string
	 */
	protected const EXTERNAL_LINK_URL = '';

	/**
	 * The popover ID.
	 *
	 * @var string
	 */
	protected const POPOVER_ID = '';

	/**
	 * Whether the task is repetitive.
	 *
	 * @var bool
	 */
	protected $is_repetitive = false;

	/**
	 * The task points.
	 *
	 * @var int
	 */
	protected $points = 1;

	/**
	 * The task parent.
	 *
	 * @var int
	 */
	protected $parent = 0;

	/**
	 * The task priority.
	 *
	 * Tasks are ordered from lowest to highest priority value (0 = highest priority, 100 = lowest priority).
	 * Use the PRIORITY_* constants defined in this class for consistency.
	 *
	 * @var int
	 */
	protected $priority = 50;

	/**
	 * Whether the task is dismissable.
	 *
	 * @var bool
	 */
	protected $is_dismissable = false;

	/**
	 * Whether the task is snoozable.
	 *
	 * @var bool
	 */
	protected $is_snoozable = true;

	/**
	 * The task URL.
	 *
	 * @var string
	 */
	protected $url = '';

	/**
	 * The task URL target.
	 *
	 * @var string
	 */
	protected $url_target = '_self';

	/**
	 * The task link setting.
	 *
	 * @var array
	 */
	protected $link_setting;

	/**
	 * The data collector.
	 *
	 * @var \Progress_Planner\Suggested_Tasks\Data_Collector\Base_Data_Collector|null
	 */
	protected $data_collector = null;

	/**
	 * Initialize the task provider.
	 *
	 * @return void
	 */
	public function init() {
	}

	/**
	 * Get the task title.
	 *
	 * @return string
	 */
	protected function get_title() {
		return '';
	}

	/**
	 * Get the task description.
	 *
	 * @return string
	 */
	protected function get_description() {
		return '';
	}

	/**
	 * Get the task points.
	 *
	 * @return int
	 */
	public function get_points() {
		return $this->points;
	}

	/**
	 * Get the task parent.
	 *
	 * @return int
	 */
	public function get_parent() {
		return $this->parent;
	}

	/**
	 * Get the popover ID.
	 *
	 * @return string
	 */
	public function get_popover_id() {
		return static::POPOVER_ID;
	}

	/**
	 * Get the task priority.
	 *
	 * @return int
	 */
	public function get_priority() {
		return (int) $this->priority;
	}

	/**
	 * Get whether the task is dismissable.
	 *
	 * @return bool
	 */
	public function is_dismissable() {
		return $this->is_dismissable;
	}

	/**
	 * Get whether the task is snoozable.
	 *
	 * @return bool
	 */
	public function is_snoozable() {
		return $this->is_snoozable;
	}

	/**
	 * Get the task URL.
	 *
	 * @return string
	 */
	protected function get_url() {
		return $this->url ? \esc_url( $this->url ) : '';
	}

	/**
	 * Get the task URL.
	 *
	 * @return string
	 */
	protected function get_url_target() {
		return $this->url_target ? $this->url_target : '_self';
	}

	/**
	 * Get the task link setting.
	 *
	 * @return array
	 */
	public function get_link_setting() {
		return $this->link_setting;
	}

	/**
	 * Get the provider ID.
	 *
	 * @return string
	 */
	public function get_provider_id() {
		return static::PROVIDER_ID;
	}

	/**
	 * Get external link URL.
	 *
	 * @return string
	 */
	public function get_external_link_url() {
		return \progress_planner()->get_ui__branding()->get_url( static::EXTERNAL_LINK_URL );
	}

	/**
	 * Get the task ID.
	 *
	 * Generates a unique task ID by combining the provider ID with optional task-specific data.
	 * For repetitive tasks, includes the current year-week (oW format) to create weekly instances.
	 *
	 * Example task IDs:
	 * - Non-repetitive: "update-core"
	 * - With post target: "update-post-123"
	 * - With term target: "update-term-5-category"
	 * - Repetitive weekly: "create-post-2025W42"
	 *
	 * @param array $task_data {
	 *     Optional data to include in the task ID.
	 *
	 *     @type int    $target_post_id  The ID of the post this task targets.
	 *     @type int    $target_term_id  The ID of the term this task targets.
	 *     @type string $target_taxonomy The taxonomy slug for term-based tasks.
	 * }
	 * @return string The generated task ID (e.g., "provider-id-123-202542").
	 */
	public function get_task_id( $task_data = [] ) {
		$parts = [ $this->get_provider_id() ];

		// Order is important here, new parameters should be added at the end.
		// This ensures existing task IDs remain consistent when new fields are added.
		$parts[] = $task_data['target_post_id'] ?? false;
		$parts[] = $task_data['target_term_id'] ?? false;
		$parts[] = $task_data['target_taxonomy'] ?? false;
		// If the task is repetitive, add the date as the last part (format: YYYYWW, e.g., 202542 for week 42 of 2025).
		// This creates a new task instance each week for repetitive tasks.
		// Note: We use 'oW' format (ISO year + ISO week) instead of 'YW' to handle year boundaries correctly.
		// For example, Dec 29, 2025 is ISO week 01 of 2026, so 'oW' returns '202601' while 'YW' would incorrectly return '202501'.
		$parts[] = $this->is_repetitive() ? \gmdate( 'oW' ) : false;

		// Remove empty parts to keep IDs clean.
		$parts = \array_filter( $parts );

		return \implode( '-', $parts );
	}

	/**
	 * Get the data collector.
	 *
	 * @return \Progress_Planner\Suggested_Tasks\Data_Collector\Base_Data_Collector
	 */
	public function get_data_collector() {
		if ( ! $this->data_collector ) {
			$class_name           = static::DATA_COLLECTOR_CLASS;
			$this->data_collector = new $class_name(); // @phpstan-ignore-line assign.propertyType
		}

		return $this->data_collector; // @phpstan-ignore-line return.type
	}

	/**
	 * Get the title with data.
	 *
	 * Allows child classes to generate dynamic task titles based on task-specific data.
	 * For example, "Update post: {post_title}" where {post_title} comes from $task_data.
	 *
	 * @param array $task_data {
	 *     Optional data to include in the task title.
	 *
	 *     @type int    $target_post_id    The ID of the post this task targets.
	 *     @type string $target_post_title The title of the post this task targets.
	 *     @type int    $target_term_id    The ID of the term this task targets.
	 *     @type string $target_term_name  The name of the term this task targets.
	 *     @type string $target_taxonomy   The taxonomy slug for term-based tasks.
	 * }
	 * @return string The task title.
	 */
	protected function get_title_with_data( $task_data = [] ) {
		return $this->get_title();
	}

	/**
	 * Get the description with data.
	 *
	 * Allows child classes to generate dynamic task descriptions based on task-specific data.
	 *
	 * @param array $task_data {
	 *     Optional data to include in the task description.
	 *
	 *     @type int    $target_post_id    The ID of the post this task targets.
	 *     @type string $target_post_title The title of the post this task targets.
	 *     @type int    $target_term_id    The ID of the term this task targets.
	 *     @type string $target_term_name  The name of the term this task targets.
	 *     @type string $target_taxonomy   The taxonomy slug for term-based tasks.
	 * }
	 * @return string The task description.
	 */
	protected function get_description_with_data( $task_data = [] ) {
		return $this->get_description();
	}

	/**
	 * Get the URL with data.
	 *
	 * Allows child classes to generate dynamic task URLs based on task-specific data.
	 * For example, a link to edit a specific post: "post.php?post={post_id}&action=edit".
	 *
	 * @param array $task_data {
	 *     Optional data to include in generating the task URL.
	 *
	 *     @type int    $target_post_id  The ID of the post this task targets.
	 *     @type int    $target_term_id  The ID of the term this task targets.
	 *     @type string $target_taxonomy The taxonomy slug for term-based tasks.
	 * }
	 * @return string The task URL (escaped and ready to use).
	 */
	protected function get_url_with_data( $task_data = [] ) {
		return $this->get_url();
	}

	/**
	 * Check if the user has the capability to perform the task.
	 *
	 * @return bool
	 */
	public function capability_required() {
		return static::CAPABILITY
			? \current_user_can( static::CAPABILITY )
			: true;
	}

	/**
	 * Check if the task is a repetitive task.
	 *
	 * @return bool
	 */
	public function is_repetitive() {
		return $this->is_repetitive;
	}

	/**
	 * Check if the task is an onboarding task.
	 *
	 * @return bool
	 */
	public function is_onboarding_task() {
		return static::IS_ONBOARDING_TASK;
	}

	/**
	 * Check if task provider is snoozed.
	 *
	 * @return bool
	 */
	public function is_task_snoozed() {
		foreach ( \progress_planner()->get_suggested_tasks_db()->get_tasks_by( [ 'post_status' => 'future' ] ) as $task ) {
			$task        = \progress_planner()->get_suggested_tasks_db()->get_post( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $task->post_name ) );
			$provider_id = $task ? $task->get_provider_id() : '';

			if ( $provider_id === $this->get_provider_id() ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if the task is still relevant.
	 * For example, we have a task to disable author archives if there is only one author.
	 * If in the meantime more authors are added, the task is no longer relevant and the task should be removed.
	 *
	 * @return bool
	 */
	public function is_task_relevant() {
		return true;
	}

	/**
	 * Evaluate a task to check if it has been completed.
	 *
	 * This method determines whether a task should be marked as completed and earn points.
	 * It handles both non-repetitive tasks (one-time) and repetitive tasks (weekly).
	 *
	 * Non-repetitive tasks:
	 * - Checks if the task belongs to this provider
	 * - Verifies completion status via is_task_completed()
	 * - Returns the task object if completed, false otherwise
	 *
	 * Repetitive tasks:
	 * - Must be completed within the same week they were created (using oW format: ISO year + ISO week number)
	 * - For example, a task created in week 42 of 2025 must be completed in 2025W42
	 * - This prevents tasks from previous weeks being marked as complete
	 * - Allows child classes to add completion data (e.g., post_id for "create post" tasks)
	 *
	 * @param string $task_id The task ID to evaluate.
	 *
	 * @return \Progress_Planner\Suggested_Tasks\Task|false The task object if completed, false otherwise.
	 */
	public function evaluate_task( $task_id ) {
		// Early bail if the user does not have the capability to manage options.
		if ( ! $this->capability_required() ) {
			return false;
		}

		$task = \progress_planner()->get_suggested_tasks_db()->get_post( $task_id );

		if ( ! $task ) {
			return false;
		}

		// Handle non-repetitive (one-time) tasks.
		if ( ! $this->is_repetitive() ) {
			// Collaborator tasks have custom task_ids, so strpos check does not work for them.
			if ( ! $task->post_name || ( 0 !== \strpos( $task->post_name, $this->get_task_id() ) && 'collaborator' !== $this->get_provider_id() ) ) {
				return false;
			}
			return $this->is_task_completed( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $task->post_name ) ) ? $task : false;
		}

		// Handle repetitive (weekly) tasks.
		// These tasks must be completed in the same week they were created.
		if (
			$task->provider &&
			$task->provider->slug === $this->get_provider_id() &&
			\DateTime::createFromFormat( 'Y-m-d H:i:s', $task->post_date ) &&
			// Check if the task was created in the current week (oW format: ISO year + ISO week, e.g., 202542 = week 42 of 2025).
			\gmdate( 'oW' ) === \gmdate( 'oW', \DateTime::createFromFormat( 'Y-m-d H:i:s', $task->post_date )->getTimestamp() ) && // @phpstan-ignore-line
			$this->is_task_completed( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $task->post_name ) )
		) {
			// Allow adding more data, for example in case of 'create-post' tasks we are adding the post_id.
			$task_data = $this->modify_evaluated_task_data( $task->get_data() );
			$task->update( $task_data );

			return $task;
		}

		return false;
	}

	/**
	 * Check if the task condition is satisfied.
	 *
	 * @return bool true means that the task condition is satisfied, meaning that we don't need to add the task or task was completed.
	 */
	abstract public function should_add_task();

	/**
	 * Alias for should_add_task(), for better readability when using in the evaluate_task() method.
	 *
	 * @param string $task_id Optional task ID to check completion for.
	 * @return bool
	 */
	public function is_task_completed( $task_id = '' ) {
		// If no specific task ID provided, use the default behavior.
		return empty( $task_id )
			? ! $this->should_add_task()
			: $this->is_specific_task_completed( $task_id );
	}

	/**
	 * Check if a specific task is completed.
	 * Child classes can override this method to handle specific task IDs.
	 *
	 * @param string $task_id The task ID to check.
	 * @return bool
	 */
	protected function is_specific_task_completed( $task_id ) {
		return ! $this->should_add_task();
	}

	/**
	 * Backwards-compatible method to check if the task condition is satisfied.
	 *
	 * @return bool
	 */
	protected function check_task_condition() {
		return ! $this->should_add_task();
	}

	/**
	 * Get an array of tasks to inject.
	 *
	 * @return array
	 */
	public function get_tasks_to_inject() {
		if (
			true === $this->is_task_snoozed() ||
			! $this->should_add_task() || // No need to add the task.
			true === \progress_planner()->get_suggested_tasks()->was_task_completed( $this->get_task_id() )
		) {
			return [];
		}

		$task_data = $this->modify_injection_task_data( $this->get_task_details() );

		// Skip the task if it was already injected.
		return \progress_planner()->get_suggested_tasks_db()->get_post( $task_data['task_id'] )
			? []
			: [ \progress_planner()->get_suggested_tasks_db()->add( $task_data ) ];
	}

	/**
	 * Modify task data before injecting it.
	 * Child classes can override this method to add extra data.
	 *
	 * @param array $task_data The task data.
	 *
	 * @return array
	 */
	protected function modify_injection_task_data( $task_data ) {
		return $task_data;
	}

	/**
	 * Modify task data after task was evaluated.
	 * Child classes can override this method to add extra data.
	 *
	 * @param array $task_data The task data.
	 *
	 * @return array
	 */
	protected function modify_evaluated_task_data( $task_data ) {
		return $task_data;
	}

	/**
	 * Get the task details.
	 *
	 * @param array $task_data The task data.
	 *
	 * @return array
	 */
	public function get_task_details( $task_data = [] ) {
		return [
			'task_id'           => $this->get_task_id( $task_data ),
			'provider_id'       => $this->get_provider_id(),
			'post_title'        => $this->get_title_with_data( $task_data ),
			'description'       => $this->get_description_with_data( $task_data ),
			'parent'            => $this->get_parent(),
			'priority'          => $this->get_priority(),
			'points'            => $this->get_points(),
			'date'              => \gmdate( 'oW' ),
			'url'               => $this->get_url_with_data( $task_data ),
			'url_target'        => $this->get_url_target(),
			'link_setting'      => $this->get_link_setting(),
			'dismissable'       => $this->is_dismissable(),
			'external_link_url' => $this->get_external_link_url(),
		];
	}

	/**
	 * Transform data collector data into task data format.
	 *
	 * @param array $data The data from data collector.
	 * @return array The transformed data with original data merged.
	 */
	protected function transform_collector_data( array $data ): array {
		$transform_keys = [
			'term_id'    => 'target_term_id',
			'taxonomy'   => 'target_taxonomy',
			'name'       => 'target_term_name',
			'post_id'    => 'target_post_id',
			'post_title' => 'target_post_title',
		];

		foreach ( $transform_keys as $key => $value ) {
			if ( isset( $data[ $key ] ) ) {
				$data[ $value ] = $data[ $key ];
			}
		}

		return $data;
	}

	/**
	 * Check if the task dependencies are satisfied.
	 *
	 * @return bool
	 */
	public function are_dependencies_satisfied() {
		foreach ( static::DEPENDENCIES as $task_id => $result ) {
			$post = \progress_planner()->get_suggested_tasks_db()->get_post( $task_id );
			if ( ! $post ) {
				return false;
			}
			$post_status = $post->post_status;
			if ( ( 'publish' === $post_status && ! $result )
				|| ( 'publish' !== $post_status && $result )
			) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Get task actions HTML buttons/links for display in the UI.
	 *
	 * Generates an array of HTML action buttons that users can interact with for each task.
	 * Actions are ordered by priority (lower numbers appear first).
	 *
	 * Standard actions include:
	 * - Complete button (priority 20): Marks task as complete and awards points
	 * - Snooze button (priority 30): Postpones task for specified duration (1 week to forever)
	 * - Info/External link (priority 40): Educational content about the task
	 * - Custom actions: Child classes can add via add_task_actions()
	 *
	 * Priority system (0-100, lower = higher priority):
	 * - 0-19: Reserved for critical actions
	 * - 20: Complete action
	 * - 30: Snooze action
	 * - 40: Information/educational links
	 * - 50+: Custom provider-specific actions
	 * - 1000: Default for actions without explicit priority
	 *
	 * @param array $data {
	 *     The task data from the REST API response.
	 *
	 *     @type int    $id                     The WordPress post ID of the task.
	 *     @type string $slug                   The task slug (post_name).
	 *     @type array  $title                  {
	 *         @type string $rendered The rendered task title.
	 *     }
	 *     @type array  $content                {
	 *         @type string $rendered The rendered task description/content.
	 *     }
	 *     @type array  $meta                   Task metadata (presence checked before processing).
	 * }
	 *
	 * @return array Array of HTML strings for action buttons/links, ordered by priority.
	 */
	public function get_task_actions( $data = [] ) {
		$actions = [];
		if ( ! isset( $data['meta'] ) ) {
			return $actions;
		}

		// Add "Mark as complete" button for dismissable tasks (except user-created tasks).
		if ( $this->capability_required() && $this->is_dismissable() && 'user' !== static::PROVIDER_ID ) {
			$actions[] = [
				'priority' => 20,
				'html'     => '<button type="button" class="prpl-suggested-task-button" data-task-id="' . \esc_attr( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $data['slug'] ) ) . '" data-task-title="' . \esc_attr( $data['title']['rendered'] ) . '" data-action="complete" data-target="complete" title="' . \esc_html__( 'Mark as complete', 'progress-planner' ) . '" onclick="prplSuggestedTask.maybeComplete(' . (int) $data['id'] . ');"><span class="prpl-tooltip-action-text">' . \esc_html__( 'Mark as complete', 'progress-planner' ) . '</span><span class="screen-reader-text">' . \esc_html__( 'Mark as complete', 'progress-planner' ) . '</span></button>',
			];
		}

		// Add "Snooze" button with duration options for snoozable tasks.
		if ( $this->capability_required() && $this->is_snoozable() ) {
			// Build snooze dropdown with custom web component (prpl-tooltip).
			$snooze_html  = '<prpl-tooltip class="prpl-suggested-task-snooze"><slot name="open"><button type="button" class="prpl-suggested-task-button" data-task-id="' . \esc_attr( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $data['slug'] ) ) . '" data-task-title="' . \esc_attr( $data['title']['rendered'] ) . '" data-action="snooze" data-target="snooze" title="' . \esc_attr__( 'Snooze', 'progress-planner' ) . '"><span class="prpl-tooltip-action-text">' . \esc_html__( 'Snooze', 'progress-planner' ) . '</span><span class="screen-reader-text">' . \esc_html__( 'Snooze', 'progress-planner' ) . '</span></button></slot><slot name="content">';
			$snooze_html .= '<fieldset><legend><span>' . \esc_html__( 'Snooze this task?', 'progress-planner' ) . '</span><button type="button" class="prpl-toggle-radio-group" onclick="this.closest(\'.prpl-suggested-task-snooze\').classList.toggle(\'prpl-toggle-radio-group-open\');"><span class="prpl-toggle-radio-group-text">' . \esc_html__( 'How long?', 'progress-planner' ) . '</span><span class="prpl-toggle-radio-group-arrow">&rsaquo;</span></button></legend><div class="prpl-snooze-duration-radio-group">';

			// Generate radio buttons for snooze duration options.
			foreach (
				[
					'1-week'   => \esc_html__( '1 week', 'progress-planner' ),
					'1-month'  => \esc_html__( '1 month', 'progress-planner' ),
					'3-months' => \esc_html__( '3 months', 'progress-planner' ),
					'6-months' => \esc_html__( '6 months', 'progress-planner' ),
					'1-year'   => \esc_html__( '1 year', 'progress-planner' ),
					'forever'  => \esc_html__( 'forever', 'progress-planner' ),
				] as $snooze_key => $snooze_value ) {
					$snooze_html .= '<label><input type="radio" name="snooze-duration-' . \esc_attr( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $data['slug'] ) ) . '" value="' . \esc_attr( $snooze_key ) . '" onchange="prplSuggestedTask.snooze(' . (int) $data['id'] . ', \'' . \esc_attr( $snooze_key ) . '\');">' . \esc_html( $snooze_value ) . '</label>';
			}
			$snooze_html .= '</div></fieldset></slot></prpl-tooltip>';
			$actions[]    = [
				'priority' => 30,
				'html'     => $snooze_html,
			];
		}

		// Add educational/informational links.
		// Prefer external links if provided, otherwise show task description in tooltip.
		if ( $this->get_external_link_url() ) {
			$actions[] = [
				'priority' => 40,
				'html'     => '<a class="prpl-tooltip-action-text" href="' . \esc_url( $this->get_external_link_url() ) . '" target="_blank">' . \esc_html__( 'Why is this important?', 'progress-planner' ) . '</a>',
			];
		} elseif ( isset( $data['content']['rendered'] ) && $data['content']['rendered'] !== '' && ! $this instanceof Tasks_Interactive ) {
			$actions[] = [
				'priority' => 40,
				'html'     => '<prpl-tooltip><slot name="open"><button type="button" class="prpl-suggested-task-button" data-task-id="' . \esc_attr( \progress_planner()->get_suggested_tasks()->get_task_id_from_slug( $data['slug'] ) ) . '" data-task-title="' . \esc_attr( $data['title']['rendered'] ) . '" data-action="info" data-target="info" title="' . \esc_html__( 'Info', 'progress-planner' ) . '"><span class="prpl-tooltip-action-text">' . \esc_html__( 'Info', 'progress-planner' ) . '</span><span class="screen-reader-text">' . \esc_html__( 'Info', 'progress-planner' ) . '</span></button></slot><slot name="content">' . \wp_kses_post( $data['content']['rendered'] ) . '</slot></prpl-tooltip>',
			];
		}

		// Allow child classes to add custom actions (e.g., "Edit Post" for content tasks).
		if ( $this->capability_required() ) {
			$actions = $this->add_task_actions( $data, $actions );

			// Ensure all actions have priority set and remove empty actions.
			foreach ( $actions as $key => $action ) {
				$actions[ $key ]['priority'] = $action['priority'] ?? 1000;
				if ( ! isset( $action['html'] ) || '' === $action['html'] ) {
					unset( $actions[ $key ] );
				}
			}
		}

		// Sort actions by priority (ascending: lower priority values appear first).
		\usort( $actions, fn( $a, $b ) => $a['priority'] - $b['priority'] );

		// Extract just the HTML strings (discard priority metadata).
		$return_actions = [];
		foreach ( $actions as $action ) {
			$return_actions[] = $action['html'];
		}

		return $return_actions;
	}

	/**
	 * Get the task actions.
	 *
	 * @param array $data The task data.
	 * @param array $actions The existing actions.
	 *
	 * @return array
	 */
	public function add_task_actions( $data = [], $actions = [] ) {
		return $actions;
	}

	/**
	 * Check if the task has activity.
	 *
	 * @param string $task_id The task ID.
	 *
	 * @return bool
	 */
	public function task_has_activity( $task_id = '' ) {
		if ( empty( $task_id ) ) {
			$task_id = $this->get_task_id();
		}

		$activity = \progress_planner()->get_activities__query()->query_activities(
			[
				'category' => 'suggested_task',
				'data_id'  => $task_id,
			]
		);

		return ! empty( $activity );
	}
}
