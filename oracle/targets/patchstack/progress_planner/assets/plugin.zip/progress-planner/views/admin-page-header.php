<?php
/**
 * Header for the admin page.
 *
 * @package Progress_Planner
 */

// Exit if accessed directly.
if ( ! \defined( 'ABSPATH' ) ) {
	exit;
}

\do_action( 'progress_planner_admin_page_header_before' );
?>
<div class="prpl-header">
	<div class="prpl-header-logo">
		<?php \progress_planner()->get_ui__branding()->the_logo(); ?>
	</div>

	<div class="prpl-header-right">
		<button class="prpl-info-icon" id="prpl-start-tour-icon-button">
			<?php \progress_planner()->the_asset( 'images/icon_tour.svg' ); ?>
			<span class="screen-reader-text"><?php \esc_html_e( 'Start tour', 'progress-planner' ); ?></span>
		</button>
		<?php

		// Render the subscribe form button and popover if the license key is not set.
		if ( 'no-license' === \progress_planner()->get_license_key() ) {
			\progress_planner()->get_ui__popover()->the_popover( 'subscribe-form' )->render_button(
				'',
				\progress_planner()->get_asset( 'images/register_icon.svg' ) . '<span class="screen-reader-text">' . \esc_html__( 'Subscribe', 'progress-planner' ) . '</span>'
			);
			// Render the subscribe form popover.
			\progress_planner()->get_ui__popover()->the_popover( 'subscribe-form' )->render();
		}
		?>
		<div class="prpl-header-select-range">
			<label for="prpl-select-range" class="screen-reader-text">
				<?php \esc_html_e( 'Select range:', 'progress-planner' ); ?>
			</label>
			<select id="prpl-select-range">
				<?php
				foreach ( [
					'-3 months'  => \esc_html__( 'Activity over the past 3 months', 'progress-planner' ),
					'-6 months'  => \esc_html__( 'Activity over the past 6 months', 'progress-planner' ),
					'-12 months' => \esc_html__( 'Activity over the past 12 months', 'progress-planner' ),
					'-18 months' => \esc_html__( 'Activity over the past 18 months', 'progress-planner' ),
					'-24 months' => \esc_html__( 'Activity over the past 24 months', 'progress-planner' ),
				] as $progress_planner_range => $progress_planner_label ) {
					\printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						\esc_attr( $progress_planner_range ),
						\selected( isset( $_GET['range'] ) ? \sanitize_text_field( \wp_unslash( $_GET['range'] ) ) : '-6 months', $progress_planner_range, false ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						\esc_html( $progress_planner_label )
					);
				}
				?>
			</select>
			<label for="prpl-select-frequency" class="screen-reader-text">
				<?php \esc_html_e( 'Select frequency:', 'progress-planner' ); ?>
			</label>
			<select id="prpl-select-frequency">
				<?php
				foreach ( [
					'weekly'  => \esc_html__( 'Weekly', 'progress-planner' ),
					'monthly' => \esc_html__( 'Monthly', 'progress-planner' ),
				] as $progress_planner_frequency => $progress_planner_label ) {
					\printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						\esc_attr( $progress_planner_frequency ),
						\selected( isset( $_GET['frequency'] ) ? \sanitize_text_field( \wp_unslash( $_GET['frequency'] ) ) : 'monthly', $progress_planner_frequency, false ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						\esc_html( $progress_planner_label )
					);
				}
				?>
			</select>
		</div>
	</div>
</div>
