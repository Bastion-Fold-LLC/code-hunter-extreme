<?php
/**
 * Widget view.
 *
 * @package Progress_Planner
 */

// Exit if accessed directly.
if ( ! \defined( 'ABSPATH' ) ) {
	exit;
}

use Progress_Planner\Badges\Monthly;

$prpl_badge = Monthly::get_instance_from_id( Monthly::get_badge_id_from_date( new \DateTime() ) );
?>
<div class="prpl-dashboard-widget">
	<div>
		<prpl-gauge
			id="prpl-gauge-ravi"
			background="#fff"
			color="var(--prpl-color-monthly)"
			contentFontSize="var(--prpl-font-size-4xl)"
			contentPadding="var(--prpl-padding)"
			marginBottom="0"
			data-max="<?php echo (int) Monthly::TARGET_POINTS; ?>"
			data-value="<?php echo (float) \progress_planner()->get_admin__widgets__monthly_badges()->get_score()['target_score']; ?>"
			data-badge-id="<?php echo \esc_attr( $prpl_badge->get_id() ); ?>"
			data-badge-name="<?php echo \esc_attr( $prpl_badge->get_name() ); ?>"
		>
			<prpl-badge
				complete="true"
				badge-id="<?php echo \esc_attr( $prpl_badge->get_id() ); ?>"
				badge-name="<?php echo \esc_attr( $prpl_badge->get_name() ); ?>"
				branding-id="<?php echo (int) \progress_planner()->get_ui__branding()->get_branding_id(); ?>"
			></prpl-badge>
		</prpl-gauge>
		<?php \esc_html_e( 'Monthly badge', 'progress-planner' ); ?>
	</div>

	<div>
		<prpl-gauge
			background="#fff"
			color="<?php echo \esc_attr( \progress_planner()->get_admin__widgets__activity_scores()->get_gauge_color( \progress_planner()->get_admin__widgets__activity_scores()->get_score() ) ); ?>"
			color2="<?php echo \esc_attr( \progress_planner()->get_admin__widgets__activity_scores()->get_gauge_color( \progress_planner()->get_admin__widgets__activity_scores()->get_score() ) ); ?>"
			contentFontSize="var(--prpl-font-size-5xl)"
			contentPadding="var(--prpl-padding)"
			marginBottom="0"
			data-max="100"
			data-value="<?php echo (float) \progress_planner()->get_admin__widgets__activity_scores()->get_score(); ?>"
		>
			<?php echo \esc_html( \progress_planner()->get_admin__widgets__activity_scores()->get_score() ); ?>
		</prpl-gauge>
		<?php \esc_html_e( 'Website activity score', 'progress-planner' ); ?>
	</div>
</div>

<hr style="margin: 1rem 0">

<h3>
	<?php
	\printf(
		/* translators: %s: Ravi's name. */
		\esc_html__( '%s\'s Recommendations', 'progress-planner' ),
		\esc_html( \progress_planner()->get_ui__branding()->get_ravi_name() )
	);
	?>
</h3>
<ul style="display:none"></ul>
<p class="prpl-suggested-tasks-loading">
	<?php \esc_html_e( 'Loading tasks...', 'progress-planner' ); ?>
</p>
<ul id="prpl-suggested-tasks-list" class="prpl-suggested-tasks-list"></ul>

<?php if ( \current_user_can( 'manage_options' ) ) : ?>
	<div class="prpl-dashboard-widget-footer">
		<span style="display:inline-flex;width:1.85em;height:1.85em;"><?php echo \progress_planner()->get_ui__branding()->get_admin_menu_icon( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG markup. ?></span>
		<div>
			<?php $prpl_pending_celebration_tasks = \progress_planner()->get_suggested_tasks_db()->get_tasks_by( [ 'post_status' => 'pending' ] ); ?>
			<?php if ( $prpl_pending_celebration_tasks ) : ?>
				<?php
				$prpl_notification_count = \count( $prpl_pending_celebration_tasks );
				\printf(
					/* translators: %s: Number of pending celebration tasks. */
					\esc_html( \_n( 'Good job! You have successfully finished %s task!', 'Good job! You have successfully finished %s tasks!', $prpl_notification_count, 'progress-planner' ) ),
					\esc_html( \number_format_i18n( $prpl_notification_count ) )
				);
				?>
				<a class="prpl-button-primary" href="<?php echo \esc_url( \get_admin_url( null, 'admin.php?page=progress-planner' ) ); ?>">
					<?php \esc_html_e( 'Celebrate your achievement!', 'progress-planner' ); ?>
				</a>
			<?php else : ?>
				<a href="<?php echo \esc_url( \get_admin_url( null, 'admin.php?page=progress-planner' ) ); ?>">
					<?php \esc_html_e( 'Check out all your stats and recommendations', 'progress-planner' ); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>

<?php
	/**
	 * Fires after the score widget is rendered.
	 *
	 * @since 1.7.1
	 */
	\do_action( 'progress_planner_admin_dashboard_widget_score_after' );
?>
